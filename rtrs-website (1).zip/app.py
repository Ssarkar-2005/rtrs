from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('rtrs.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/trains')
def trains():
    conn = get_db_connection()
    trains = conn.execute('SELECT * FROM trains').fetchall()
    conn.close()
    return render_template('trains.html', trains=trains)

@app.route('/book/<int:train_no>')
def book(train_no):
    conn = get_db_connection()
    train = conn.execute('SELECT * FROM trains WHERE train_no = ?', (train_no,)).fetchone()
    conn.close()
    return render_template('book.html', train=train)

@app.route('/confirm_booking', methods=['POST'])
def confirm_booking():
    passenger_name = request.form['passenger_name']
    train_no = request.form['train_no']
    seats_booked = int(request.form['seats_booked'])

    conn = get_db_connection()
    train = conn.execute('SELECT * FROM trains WHERE train_no = ?', (train_no,)).fetchone()

    if train and seats_booked <= train['seats_available']:
        conn.execute('INSERT INTO bookings (passenger_name, train_no, seats_booked) VALUES (?, ?, ?)',
                     (passenger_name, train_no, seats_booked))
        conn.execute('UPDATE trains SET seats_available = seats_available - ? WHERE train_no = ?',
                     (seats_booked, train_no))
        conn.commit()
        conn.close()
        return render_template('confirmation.html', passenger_name=passenger_name, train=train, seats_booked=seats_booked)
    else:
        conn.close()
        return "Not enough seats available or invalid train!"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
