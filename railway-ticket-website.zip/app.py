import streamlit as st
import joblib
import pandas as pd

# Load model
model = joblib.load('model.pkl')

st.title("Railway Ticket Reservation System")

# User Inputs
source = st.text_input("Enter Source Station")
destination = st.text_input("Enter Destination Station")
season = st.selectbox("Select Season", ["Summer", "Winter", "Monsoon"])
day_of_week = st.selectbox("Select Day", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])

if st.button("Predict Seats Availability"):
    input_df = pd.DataFrame({
        'source_station': [source],
        'destination_station': [destination],
        'season': [season],
        'day_of_week': [day_of_week]
    })
    prediction = model.predict(input_df)
    st.success(f"Estimated Available Seats: {prediction[0]}")